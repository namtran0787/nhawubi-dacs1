const Credentials = () => {

    return {
        ClientId: 'ENTER YOUR CLIENT ID',
        ClientSecret: 'ENTER YOUR CLIENT SECRET'
    }
}

export { Credentials };